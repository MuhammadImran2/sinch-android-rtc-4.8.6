package com.sinch.android.rtc.sample.hmspush;

import android.content.Context;
import android.content.SharedPreferences;

public class PersistedHmsRegistration {

    private static final String PREF_NAME = "persistedHmsRegistrationData";
    private static final String HMS_TOKEN = "hmsToken";
    private static final String HMS_APP_ID = "hmsAppId";

    private static SharedPreferences getSharedPref(Context context) {
        return context.getSharedPreferences(PREF_NAME, Context.MODE_PRIVATE);
    }

    public static String getHmsToken(Context context) {
        return getSharedPref(context).getString(HMS_TOKEN, "");
    }

    public static void setHmsToken(Context context, String token) {
        getSharedPref(context).edit().putString(HMS_TOKEN, token).commit();
    }

    public static String getHmsApplicationId(Context context) {
        return getSharedPref(context).getString(HMS_APP_ID, "");
    }

    public static void setHmsApplicationId(Context context, String id) {
        getSharedPref(context).edit().putString(HMS_APP_ID, id).commit();
    }
}

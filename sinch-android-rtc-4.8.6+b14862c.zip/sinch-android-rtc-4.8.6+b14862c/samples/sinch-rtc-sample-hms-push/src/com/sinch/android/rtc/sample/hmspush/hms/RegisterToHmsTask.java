package com.sinch.android.rtc.sample.hmspush.hms;

import android.content.Context;
import android.os.AsyncTask;
import android.util.Log;

import com.huawei.agconnect.config.AGConnectServicesConfig;
import com.huawei.hms.aaid.HmsInstanceId;
import com.huawei.hms.common.ApiException;

import java.util.HashMap;
import java.util.Map;

public class RegisterToHmsTask extends AsyncTask<Void, Void, Map<String,String>> {
    public interface RegistrationCallback {
        void onRegisterComplete(String deviceToken, String applicationId);
    }

    private final String HMS_APPLICATION_ID_KEY = "HMS_APPLICATION_ID";
    private final String HMS_DEVICE_TOKEN_KEY = "HMS_DEVICE_TOKEN";

    private Context context;
    private final String TAG = RegisterToHmsTask.class.getSimpleName();

    private com.sinch.android.rtc.sample.hmspush.hms.RegisterToHmsTask.RegistrationCallback callback;

    public RegisterToHmsTask(Context context, com.sinch.android.rtc.sample.hmspush.hms.RegisterToHmsTask.RegistrationCallback callback) {
        this.context = context;
        this.callback = callback;
    }

    @Override
    protected Map<String,String> doInBackground(Void... params) {
        Map<String,String> regId = null;
        try {
            // read from agconnect-services.json
            String appId = AGConnectServicesConfig.fromContext(context).getString("client/app_id");
            String token = HmsInstanceId.getInstance(context).getToken(appId, "HCM");
            regId = new HashMap<>();
            regId.put(HMS_APPLICATION_ID_KEY, appId);
            regId.put(HMS_DEVICE_TOKEN_KEY, token);
            Log.i(TAG, "get token:" + regId);
        } catch (ApiException e) {
            Log.e(TAG, "get token failed, " + e);
        }
        return regId;
    }

    @Override
    protected void onPostExecute(Map<String,String> regId) {
        if (regId != null) {
            callback.onRegisterComplete(regId.get(HMS_DEVICE_TOKEN_KEY), regId.get(HMS_APPLICATION_ID_KEY));
        } else {
            callback.onRegisterComplete(null, null);
        }
    }
}
package com.sinch.android.rtc.sample.hmspush;

import com.sinch.android.rtc.ClientRegistration;
import com.sinch.android.rtc.PushTokenRegistrationCallback;
import com.sinch.android.rtc.Sinch;
import com.sinch.android.rtc.SinchError;
import com.sinch.android.rtc.UserController;
import com.sinch.android.rtc.UserRegistrationCallback;
import com.sinch.android.rtc.sample.hmspush.hms.RegisterToHmsTask;

import android.app.ProgressDialog;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import static com.sinch.android.rtc.sample.hmspush.SinchService.APP_KEY;
import static com.sinch.android.rtc.sample.hmspush.SinchService.APP_SECRET;
import static com.sinch.android.rtc.sample.hmspush.SinchService.ENVIRONMENT;

public class LoginActivity extends com.sinch.android.rtc.sample.hmspush.BaseActivity implements SinchService.StartFailedListener, PushTokenRegistrationCallback, UserRegistrationCallback, RegisterToHmsTask.RegistrationCallback {

    private Button mLoginButton;
    private EditText mLoginName;
    private ProgressDialog mSpinner;
    private String mUserId;
    private String mHmsDeviceToken;
    private String mHmsApplicationId;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.login);

        mLoginName = findViewById(R.id.loginName);

        mLoginButton = findViewById(R.id.loginButton);
        mLoginButton.setEnabled(false);
        mLoginButton.setOnClickListener(v -> loginClicked());
    }

    @Override
    protected void onResume() {
        super.onResume();
        if (mHmsDeviceToken != null && !mHmsDeviceToken.isEmpty()) {
            mLoginButton.setEnabled(true);
            mLoginButton.setVisibility(View.VISIBLE);
        } else {
            // Huawei recommends reacquiring the Device Token each app start.
            // For simplicity of UI handling we demonstrate it here.
            mLoginButton.setVisibility(View.INVISIBLE);
            RegisterToHmsTask task = new RegisterToHmsTask(getApplicationContext(), this);
            task.execute();
        }
    }

    @Override
    protected void onServiceConnected() {
        if (getSinchServiceInterface().isStarted()) {
            openPlaceCallActivity();
        } else {
            getSinchServiceInterface().setStartListener(this);
        }
    }

    @Override
    protected void onPause() {
        dismissSpinner();
        super.onPause();
    }

    @Override
    public void onFailed(SinchError error) {
        Toast.makeText(this, error.toString(), Toast.LENGTH_LONG).show();
        dismissSpinner();
    }

    @Override
    public void onStarted() {
        openPlaceCallActivity();
    }

    private void startClientAndOpenPlaceCallActivity() {
        // start Sinch Client, it'll result onStarted() callback from where the place call activity will be started
        if (!getSinchServiceInterface().isStarted()) {
            getSinchServiceInterface().startClient();
            showSpinner();
        }
    }


    private void loginClicked() {
        String username = mLoginName.getText().toString();
        getSinchServiceInterface().setUsername(username);

        if (username.isEmpty()) {
            Toast.makeText(this, "Please enter a name", Toast.LENGTH_LONG).show();
            return;
        }

        mUserId = username;
        UserController uc = Sinch.getUserControllerBuilder()
                    .context(getApplicationContext())
                    .applicationKey(APP_KEY)
                    .userId(mUserId)
                    .environmentHost(ENVIRONMENT)
                    .hms()
                        .deviceToken(mHmsDeviceToken)
                        .applicationId(mHmsApplicationId)
                        .done()
                    .build();

        uc.registerUser(this, this);
    }

    private void openPlaceCallActivity() {
        Intent mainActivity = new Intent(this, PlaceCallActivity.class);
        startActivity(mainActivity);
    }

    private void showSpinner() {
        mSpinner = new ProgressDialog(this);
        mSpinner.setTitle("Logging in");
        mSpinner.setMessage("Please wait...");
        mSpinner.show();
    }

    private void dismissSpinner() {
        if (mSpinner != null) {
            mSpinner.dismiss();
            mSpinner = null;
        }
    }

    @Override
    public void onUserRegistrationFailed(SinchError sinchError) {
        dismissSpinner();
        Toast.makeText(this, "Registration failed!", Toast.LENGTH_LONG).show();
    }

    @Override
    public void onUserRegistered() {
        // Instance is registered, but we'll wait for another callback, assuring that the push token is
        // registered as well, meaning we can receive incoming calls.
    }

    @Override
    public void onPushTokenRegistered() {
        dismissSpinner();
        startClientAndOpenPlaceCallActivity();
    }

    @Override
    public void onPushTokenRegistrationFailed(SinchError sinchError) {
        dismissSpinner();
        Toast.makeText(this, "Push token registration failed - incoming calls can't be received!", Toast.LENGTH_LONG).show();
    }

    // The most secure way is to obtain the credentials from the backend,
    // since storing the Application Secret in the app is not safe.
    // Following code demonstrates how the JWT that serves as credential should be created,
    // provided the Application Key (APP_KEY), Application Secret (APP_SECRET) and User ID.

    @Override
    public void onCredentialsRequired(ClientRegistration clientRegistration) {
        // NB: This implementation just emulates what should be an async procedure, with JWT.create() being
        // run on your backend.
        clientRegistration.register(JWT.create(APP_KEY, APP_SECRET,mUserId));
    }


    @Override
    public void onRegisterComplete(String deviceToken, String applicationId) {
        mHmsDeviceToken = deviceToken;
        mHmsApplicationId = applicationId;
        if (mHmsDeviceToken == null || mHmsDeviceToken.isEmpty()) {
            Toast.makeText(this, "Failed to get HMS Device Token. Make sure that the app is signed and the signature's fingerprint is uploaded to the Huawei AppGallery console.", Toast.LENGTH_LONG).show();
            mLoginButton.setEnabled(false);
            return;
        } else {
            // Store HMS registration data to use it when creating SinchClient.
            PersistedHmsRegistration.setHmsToken(getApplicationContext(), mHmsDeviceToken);
            PersistedHmsRegistration.setHmsApplicationId(getApplicationContext(), mHmsApplicationId);
            mLoginButton.setVisibility(View.VISIBLE);
            mLoginButton.setEnabled(true);
        }
    }
}
